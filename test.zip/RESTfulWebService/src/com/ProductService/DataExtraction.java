package com.ProductService;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;

public class DataExtraction {
	private static final String APIKEY_Walmart="rm25tyum3p9jm9x9x7zxshfa";
	private static final String APIKEY_BestBuy="pfe9fpy68yg28hvvma49sc89";
	
	//http://api.walmartlabs.com/v1/search?query=iPad%20Mini&format=json&apikey=rm25tyum3p9jm9x9x7zxshfa
		//https://api.bestbuy.com/v1/products?apiKey=pfe9fpy68yg28hvvma49sc89
	private static final String walmartUrl = "http://api.walmartlabs.com/v1/search?query=";
	private static final String bestBuyUrl = "https://api.bestbuy.com/v1/products?apiKey=";
	
	//********************/
	public static Root getProductsInfo(String productName, String whoIquery){
		
		
		String jsonText = getProductJsonText(productName, whoIquery);
		Root ProductOject= toEntity(jsonText);
		
		return ProductOject;
		
	}
	//******************
	// convert json string to class object
	
	private static Root toEntity(String jsonText){
		try{
			Gson gson = new GsonBuilder().create();
			Root productInfo =gson.fromJson(jsonText,  Root.class);
			return productInfo;
		}catch(JsonSyntaxException e){
			e.printStackTrace();
			return null;
		}
	}
	
		// get Price of a product
	
	private static String getProductJsonText(String productName, String whoIquery) throws RuntimeException{
		//storing the url related to the product name ipad Mini as default
	if(whoIquery.equalsIgnoreCase("walmart")) {
		String defaultWalmartUrl = walmartUrl + "ipad Mini"; //this defaut value will be stored in config file
		try{
			if(productName!=null && productName!="")
				defaultWalmartUrl = walmartUrl + URLEncoder.encode(productName, "utf-8");
		}catch(UnsupportedEncodingException e){
			e.printStackTrace();
		}
		StringBuilder stringBuilder = new StringBuilder();
		HttpURLConnection conn=null;
		BufferedReader reader = null;
		try{
			URL url = new URL(defaultWalmartUrl);
			conn=(HttpURLConnection)url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", APIKEY_Walmart);
			
			if(conn.getResponseCode() !=200){
				throw new RuntimeException("HTTP GET Request Failled with error code:"+ conn.getResponseCode());
			}
			
			// reading the contain
			
			reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
			String out =null;
			while((out = reader.readLine()) !=null)
				stringBuilder.append(out);
		}catch(MalformedURLException e){
			e.printStackTrace();
		}catch(IOException e){
			e.printStackTrace();
		}
		
		finally{
			if (reader !=null){
				try{
					reader.close();
				
				}catch(IOException e){
					e.printStackTrace();
				}
			}
			if(conn!=null){
				conn.disconnect();
			}
		}
		return stringBuilder.toString();
	}else{
		String defaultWalmartUrl = bestBuyUrl + "ipad Mini"; //this defaut value will be stored in config file
		try{
			if(productName!=null && productName!="")
				defaultWalmartUrl = bestBuyUrl + URLEncoder.encode(productName, "utf-8");
		}catch(UnsupportedEncodingException e){
			e.printStackTrace();
		}
		StringBuilder stringBuilder = new StringBuilder();
		HttpURLConnection conn=null;
		BufferedReader reader = null;
		try{
			URL url = new URL(defaultWalmartUrl);
			conn=(HttpURLConnection)url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", APIKEY_BestBuy);
			
			if(conn.getResponseCode() !=200){
				throw new RuntimeException("HTTP GET Request Failled with error code:"+ conn.getResponseCode());
			}
			
			// reading the contain
			
			reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
			String out =null;
			while((out = reader.readLine()) !=null)
				stringBuilder.append(out);
		}catch(MalformedURLException e){
			e.printStackTrace();
		}catch(IOException e){
			e.printStackTrace();
		}
		
		finally{
			if (reader !=null){
				try{
					reader.close();
				
				}catch(IOException e){
					e.printStackTrace();
				}
			}
			if(conn!=null){
				conn.disconnect();
			}
		}
		return stringBuilder.toString();
	
	}
	
	
	
	
	}	
	
	
	
}
