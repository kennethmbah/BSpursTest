package com.ProductService;

import com.google.gson.annotations.Expose;

public class Product {

	/**
	"productName": "iPad Mini",
    "bestPrice": "150.00",
    "currency": "CAD",
    "location": "Walmart"
	 */
	private String productName;
	private Double bestPrice;
	private double currency;
	private String location;
	private double salePrice;
	
	
	
	
	public double getSalePrice() {
		return salePrice;
	}


	public void setSalePrice(double salePrice) {
		this.salePrice = salePrice;
	}


	public Product(Double bestPrice, double currency, String location, String productName) {
		this.bestPrice = bestPrice;
		this.currency = currency;
		this.location = location;
		this.productName = productName;
	}
	

	public String getProductName() {
		return productName;
	}
	
	public void setProductName(String productName) {
		this.productName = productName;
	}
	
	public Double getBestPrice() {
		return bestPrice;
	}
	
	public void setBestPrice(Double bestPrice) {
		this.bestPrice = bestPrice;
	}
	
	public double getCurrency() {
		return currency;
	}
	
	public void setCurrency(double currency) {
		this.currency = currency;
	}
	
	public String getLocation() {
		return location;
	}
	
	public void setLocation(String location) {
		this.location = location;
	}
	
	
	
}
