package com.ProductService;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Root {
	
	@SerializedName("product data service")
	@Expose
	private List<Product> productDataService = new ArrayList<Product>();

	
	public List<Product> getProduct(){
		return productDataService;
	}
	
	
	public void setProduct(List<Product> productDataService){
		this.productDataService = productDataService;
	}
}
