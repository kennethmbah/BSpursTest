package com.ProductService.Servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.ProductService.*;
/**
 * Servlet implementation class productServlet
 */
@WebServlet("/productServlet")
public class productServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public productServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// getting product json info and convert it to object
		String name=request.getParameter("name");
		
		Root productInfoObject = DataExtraction.getProductsInfo(name,"walmart");
		if(productInfoObject!=null){
			List<Product> productList = productInfoObject.getProduct();
			double  min = productList.get(0).getSalePrice(); //  min saleprice of the product
			if(productList!=null){
				// do work *******************************
				// we have to iterate over the list,  
				// select the product with poductname =name
				// get it current price
				// query Bestbuy with the api key using the above productname=name and get the bestprice of this product
				// compare and return the lowest price
			
				// let check the current price of the product with name name
				 double value=0.0;
				 double valuee=0.0;
				 double  minbestbuy=0.0;
				for(int i=1; i< productList.size(); i++ ){
					Product product = productList.get(i);
					value= product.getSalePrice();
					if(value<min)
						min=value;
				} // min contains the current saleprice of the product with name name
				
				// let's query bestbuy to have the best pr
				Root productInfoObj = DataExtraction.getProductsInfo(name,"bestbuy");
				if(productInfoObj !=null){
					List<Product> productLists = productInfoObj.getProduct();
					  minbestbuy = productLists.get(0).getBestPrice(); // min bestbuy of the same product
					if(productList!=null){
						
						for(int i=1; i< productList.size(); i++ ){
							Product product = productList.get(i);
							valuee= product.getBestPrice();
							if(valuee<minbestbuy)
								minbestbuy=valuee;
					}
				}
			}
				if(minbestbuy<min){
					// output
					StringBuilder outputContent = new StringBuilder();
					outputContent.append("<!<DOCTYPE html><html><head><meta charset=\"UTF-8\">"
							+ "<tilte>Lowest product price</title><head><body><form action=\"product\" method=\"GET\"><select name\"product\"><option"
							+ "value =\"ipad Mini\"> ipad Mini </option></select><input type=\"submit\" value=\"Submit\"></form>");
					outputContent.append("ProductName:"+ name);
					outputContent.append("<br/>");
					outputContent.append("BestPrice:"+ minbestbuy);
					outputContent.append("<br/>");
					outputContent.append(productList.get(productList.indexOf(name)).getCurrency());
					outputContent.append("<br/>");
					outputContent.append(productList.get(productList.indexOf(name)).getLocation());
					outputContent.append("</body></html>");
					
					response.setContentType("text/html ; charset=utf-8");
					response.getWriter().write(outputContent.toString());
				}
		}
		
	}
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
